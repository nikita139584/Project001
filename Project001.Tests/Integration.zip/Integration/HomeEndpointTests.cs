using System.Net;
using Xunit;
using System.Net;
namespace Project001.Tests.Integration;

public class HomeEndpointTests : IClassFixture<Project001WebApplicationFactory>
{
    private readonly Project001WebApplicationFactory _factory;

    public HomeEndpointTests(Project001WebApplicationFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task GetHome_ReturnsOkAndRendersHomePage()
    {
        using var client = _factory.CreateClient();

        var response = await client.GetAsync("/Home/Index");
        var body = await response.Content.ReadAsStringAsync();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains("Recipe.Site", body);
    }
}
