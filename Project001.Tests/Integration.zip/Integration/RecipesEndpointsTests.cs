using System.Net;
using Moq;
using Xunit;
using System.Net;

namespace Project001.Tests.Integration;

public class RecipesEndpointsTests : IClassFixture<Project001WebApplicationFactory>
{
    private readonly Project001WebApplicationFactory _factory;

    public RecipesEndpointsTests(Project001WebApplicationFactory factory)
    {
        _factory = factory;
        _factory.RecipeServiceMock.Reset();
    }

    [Fact]
    public async Task GetRecipes_ReturnsOkAndRendersRecipeData()
    {
        var recipes = new List<Recipe>
        {
            new()
            {
                RecipeId = "recipe-1",
                Title = "Test Pasta",
                Description = "Simple test recipe",
                Ingredients = "Pasta",
                Instructions = "Cook pasta"
            }
        };

        _factory.RecipeServiceMock
            .Setup(s => s.GetAllAsync())
            .ReturnsAsync(recipes);

        using var client = _factory.CreateClient();

        var response = await client.GetAsync("/Recipes");
        var body = await response.Content.ReadAsStringAsync();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains("Test Pasta", body);
        _factory.RecipeServiceMock.Verify(s => s.GetAllAsync(), Times.Once);
    }

    [Fact]
    public async Task GetRecipeDetails_ReturnsOkForExistingRecipe()
    {
        var recipe = new Recipe
        {
            RecipeId = "recipe-1",
            Title = "Test Soup",
            Description = "Test description",
            Ingredients = "Water",
            Instructions = "Boil"
        };

        _factory.RecipeServiceMock
            .Setup(s => s.GetByIdAsync("recipe-1"))
            .ReturnsAsync(recipe);

        using var client = _factory.CreateClient();

        var response = await client.GetAsync("/Recipes/Details?id=recipe-1");
        var body = await response.Content.ReadAsStringAsync();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains("Test Soup", body);
        _factory.RecipeServiceMock.Verify(s => s.GetByIdAsync("recipe-1"), Times.Once);
    }

    [Fact]
    public async Task GetRecipeDetails_ReturnsNotFoundWhenRecipeDoesNotExist()
    {
        _factory.RecipeServiceMock
            .Setup(s => s.GetByIdAsync("missing"))
            .ReturnsAsync((Recipe?)null);

        using var client = _factory.CreateClient();

        var response = await client.GetAsync("/Recipes/Details?id=missing");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task GetRecipeDetails_ReturnsNotFoundWhenIdIsMissing()
    {
        using var client = _factory.CreateClient();

        var response = await client.GetAsync("/Recipes/Details");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}
