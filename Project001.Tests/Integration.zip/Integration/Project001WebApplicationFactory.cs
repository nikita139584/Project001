using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Moq;

namespace Project001.Tests.Integration;

public sealed class Project001WebApplicationFactory : WebApplicationFactory<Project001.Program>
{
    public Mock<IRecipeService> RecipeServiceMock { get; } = new();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");

        builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<IRecipeService>();
            services.AddSingleton(RecipeServiceMock.Object);
        });
    }
}
