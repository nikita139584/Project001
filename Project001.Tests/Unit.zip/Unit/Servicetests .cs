﻿using Moq;
using Xunit;

namespace Project001.Tests.Unit.Services;

public class RecipeServiceTests
{
    private readonly Mock<IRecipeRepository> _repository = new();
    private readonly RecipeService _service;

    public RecipeServiceTests()
    {
        _service = new RecipeService(_repository.Object);
    }

    [Fact]
    public async Task GetAllAsync_ReturnsItemsFromRepository()
    {
        var items = new List<Recipe>
        {
            new() { RecipeId = "recipe-1", Title = "Pasta" },
            new() { RecipeId = "recipe-2", Title = "Soup" }
        };
        _repository.Setup(r => r.GetAllAsync()).ReturnsAsync(items);

        var result = await _service.GetAllAsync();

        Assert.Same(items, result);
        Assert.Equal(2, result.Count);
        _repository.Verify(r => r.GetAllAsync(), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsItem_WhenItExists()
    {
        var item = new Recipe { RecipeId = "recipe-1", Title = "Pasta" };
        _repository.Setup(r => r.GetByIdAsync("recipe-1")).ReturnsAsync(item);

        var result = await _service.GetByIdAsync("recipe-1");

        Assert.Same(item, result);
        _repository.Verify(r => r.GetByIdAsync("recipe-1"), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNull_WhenItDoesNotExist()
    {
        _repository.Setup(r => r.GetByIdAsync("missing")).ReturnsAsync((Recipe?)null);

        var result = await _service.GetByIdAsync("missing");

        Assert.Null(result);
    }

    [Fact]
    public async Task CreateAsync_PassesEntityToRepository()
    {
        var item = new Recipe { Title = "Pasta" };

        await _service.CreateAsync(item);

        _repository.Verify(r => r.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task UpdateAsync_PassesEntityToRepository()
    {
        var item = new Recipe { RecipeId = "recipe-1", Title = "Soup" };

        await _service.UpdateAsync(item);

        _repository.Verify(r => r.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteAsync_PassesIdToRepository()
    {
        await _service.DeleteAsync("recipe-1");

        _repository.Verify(r => r.DeleteAsync("recipe-1"), Times.Once);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ExistsAsync_ReturnsRepositoryResult(bool exists)
    {
        _repository.Setup(r => r.ExistsAsync("recipe-1")).ReturnsAsync(exists);

        var result = await _service.ExistsAsync("recipe-1");

        Assert.Equal(exists, result);
    }
}

public class BlogServiceTests
{
    private readonly Mock<IBlogRepository> _repository = new();
    private readonly BlogService _service;

    public BlogServiceTests()
    {
        _service = new BlogService(_repository.Object);
    }

    [Fact]
    public async Task GetAllAsync_ReturnsItemsFromRepository()
    {
        var items = new List<Blog>
        {
            new() { BlogId = "blog-1", Title = "Cooking" },
            new() { BlogId = "blog-2", Title = "Travel" }
        };
        _repository.Setup(r => r.GetAllAsync()).ReturnsAsync(items);

        var result = await _service.GetAllAsync();

        Assert.Same(items, result);
        Assert.Equal(2, result.Count);
        _repository.Verify(r => r.GetAllAsync(), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsItem_WhenItExists()
    {
        var item = new Blog { BlogId = "blog-1", Title = "Cooking" };
        _repository.Setup(r => r.GetByIdAsync("blog-1")).ReturnsAsync(item);

        var result = await _service.GetByIdAsync("blog-1");

        Assert.Same(item, result);
        _repository.Verify(r => r.GetByIdAsync("blog-1"), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNull_WhenItDoesNotExist()
    {
        _repository.Setup(r => r.GetByIdAsync("missing")).ReturnsAsync((Blog?)null);

        var result = await _service.GetByIdAsync("missing");

        Assert.Null(result);
    }

    [Fact]
    public async Task CreateAsync_PassesEntityToRepository()
    {
        var item = new Blog { Title = "Cooking" };

        await _service.CreateAsync(item);

        _repository.Verify(r => r.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task UpdateAsync_PassesEntityToRepository()
    {
        var item = new Blog { BlogId = "blog-1", Title = "Travel" };

        await _service.UpdateAsync(item);

        _repository.Verify(r => r.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteAsync_PassesIdToRepository()
    {
        await _service.DeleteAsync("blog-1");

        _repository.Verify(r => r.DeleteAsync("blog-1"), Times.Once);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ExistsAsync_ReturnsRepositoryResult(bool exists)
    {
        _repository.Setup(r => r.ExistsAsync("blog-1")).ReturnsAsync(exists);

        var result = await _service.ExistsAsync("blog-1");

        Assert.Equal(exists, result);
    }
}

public class PostServiceTests
{
    private readonly Mock<IPostRepository> _repository = new();
    private readonly PostService _service;

    public PostServiceTests()
    {
        _service = new PostService(_repository.Object);
    }

    [Fact]
    public async Task GetAllAsync_ReturnsItemsFromRepository()
    {
        var items = new List<Post>
        {
            new() { PostId = "post-1", BlogId = "blog-1", Title = "First post" },
            new() { PostId = "post-2", BlogId = "blog-1", Title = "Second post" }
        };
        _repository.Setup(r => r.GetAllAsync()).ReturnsAsync(items);

        var result = await _service.GetAllAsync();

        Assert.Same(items, result);
        Assert.Equal(2, result.Count);
        _repository.Verify(r => r.GetAllAsync(), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsItem_WhenItExists()
    {
        var item = new Post { PostId = "post-1", BlogId = "blog-1", Title = "First post" };
        _repository.Setup(r => r.GetByIdAsync("post-1")).ReturnsAsync(item);

        var result = await _service.GetByIdAsync("post-1");

        Assert.Same(item, result);
        _repository.Verify(r => r.GetByIdAsync("post-1"), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNull_WhenItDoesNotExist()
    {
        _repository.Setup(r => r.GetByIdAsync("missing")).ReturnsAsync((Post?)null);

        var result = await _service.GetByIdAsync("missing");

        Assert.Null(result);
    }

    [Fact]
    public async Task GetByBlogIdAsync_ReturnsItemsFromRepository()
    {
        var items = new List<Post>
        {
            new() { PostId = "post-1", BlogId = "blog-1" },
            new() { PostId = "post-2", BlogId = "blog-1" }
        };
        _repository.Setup(r => r.GetByBlogIdAsync("blog-1")).ReturnsAsync(items);

        var result = await _service.GetByBlogIdAsync("blog-1");

        Assert.Same(items, result);
        Assert.All(result, x => Assert.Equal("blog-1", x.BlogId));
        _repository.Verify(r => r.GetByBlogIdAsync("blog-1"), Times.Once);
    }

    [Fact]
    public async Task CreateAsync_PassesEntityToRepository()
    {
        var item = new Post { BlogId = "blog-1", Title = "First post" };

        await _service.CreateAsync(item);

        _repository.Verify(r => r.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task UpdateAsync_PassesEntityToRepository()
    {
        var item = new Post { PostId = "post-1", BlogId = "blog-1", Title = "Second post" };

        await _service.UpdateAsync(item);

        _repository.Verify(r => r.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteAsync_PassesIdToRepository()
    {
        await _service.DeleteAsync("post-1");

        _repository.Verify(r => r.DeleteAsync("post-1"), Times.Once);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ExistsAsync_ReturnsRepositoryResult(bool exists)
    {
        _repository.Setup(r => r.ExistsAsync("post-1")).ReturnsAsync(exists);

        var result = await _service.ExistsAsync("post-1");

        Assert.Equal(exists, result);
    }
}

public class RatingServiceTests
{
    private readonly Mock<IRatingRepository> _repository = new();
    private readonly RatingService _service;

    public RatingServiceTests()
    {
        _service = new RatingService(_repository.Object);
    }

    [Fact]
    public async Task GetAllAsync_ReturnsItemsFromRepository()
    {
        var items = new List<Rating>
        {
            new() { RatingId = "rating-1", RecipeId = "recipe-1", Value = 5 },
            new() { RatingId = "rating-2", RecipeId = "recipe-1", Value = 4 }
        };
        _repository.Setup(r => r.GetAllAsync()).ReturnsAsync(items);

        var result = await _service.GetAllAsync();

        Assert.Same(items, result);
        Assert.Equal(2, result.Count);
        _repository.Verify(r => r.GetAllAsync(), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsItem_WhenItExists()
    {
        var item = new Rating { RatingId = "rating-1", RecipeId = "recipe-1", Value = 5 };
        _repository.Setup(r => r.GetByIdAsync("rating-1")).ReturnsAsync(item);

        var result = await _service.GetByIdAsync("rating-1");

        Assert.Same(item, result);
        _repository.Verify(r => r.GetByIdAsync("rating-1"), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNull_WhenItDoesNotExist()
    {
        _repository.Setup(r => r.GetByIdAsync("missing")).ReturnsAsync((Rating?)null);

        var result = await _service.GetByIdAsync("missing");

        Assert.Null(result);
    }

    [Fact]
    public async Task GetByRecipeIdAsync_ReturnsItemsFromRepository()
    {
        var items = new List<Rating>
        {
            new() { RatingId = "rating-1", RecipeId = "recipe-1" },
            new() { RatingId = "rating-2", RecipeId = "recipe-1" }
        };
        _repository.Setup(r => r.GetByRecipeIdAsync("recipe-1")).ReturnsAsync(items);

        var result = await _service.GetByRecipeIdAsync("recipe-1");

        Assert.Same(items, result);
        Assert.All(result, x => Assert.Equal("recipe-1", x.RecipeId));
        _repository.Verify(r => r.GetByRecipeIdAsync("recipe-1"), Times.Once);
    }

    [Fact]
    public async Task CreateAsync_PassesEntityToRepository()
    {
        var item = new Rating { RecipeId = "recipe-1", Value = 5 };

        await _service.CreateAsync(item);

        _repository.Verify(r => r.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task UpdateAsync_PassesEntityToRepository()
    {
        var item = new Rating { RatingId = "rating-1", RecipeId = "recipe-1", Value = 4 };

        await _service.UpdateAsync(item);

        _repository.Verify(r => r.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteAsync_PassesIdToRepository()
    {
        await _service.DeleteAsync("rating-1");

        _repository.Verify(r => r.DeleteAsync("rating-1"), Times.Once);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ExistsAsync_ReturnsRepositoryResult(bool exists)
    {
        _repository.Setup(r => r.ExistsAsync("rating-1")).ReturnsAsync(exists);

        var result = await _service.ExistsAsync("rating-1");

        Assert.Equal(exists, result);
    }
}