﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project001.Tests.Unit
{
    internal class RatingServiceTests
    {
    }
}
