﻿using Moq;
using Xunit;

namespace Project001.Tests.Unit;

public class CommentServiceTests
{
    private readonly Mock<ICommentRepository> _repository = new();
    private readonly CommentService _service;

    public CommentServiceTests()
    {
        _service = new CommentService(_repository.Object);
    }

    [Fact]
    public async Task GetAllAsync_ReturnsComments()
    {
        var comments = new List<Comment>
        {
            new() { CommentId = "1", Content = "Good post" },
            new() { CommentId = "2", Content = "Interesting" }
        };

        _repository.Setup(r => r.GetAllAsync())
            .ReturnsAsync(comments);

        var result = await _service.GetAllAsync();

        Assert.Same(comments, result);
        Assert.Equal(2, result.Count);
        _repository.Verify(r => r.GetAllAsync(), Times.Once);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsComment()
    {
        var comment = new Comment
        {
            CommentId = "comment-1",
            Content = "Nice!"
        };

        _repository.Setup(r => r.GetByIdAsync("comment-1"))
            .ReturnsAsync(comment);

        var result = await _service.GetByIdAsync("comment-1");

        Assert.Same(comment, result);
    }

    [Fact]
    public async Task GetByIdAsync_ReturnsNullForMissingComment()
    {
        _repository.Setup(r => r.GetByIdAsync("missing"))
            .ReturnsAsync((Comment?)null);

        var result = await _service.GetByIdAsync("missing");

        Assert.Null(result);
    }

    [Fact]
    public async Task GetByPostIdAsync_ReturnsCommentsForPost()
    {
        var comments = new List<Comment>
        {
            new() { CommentId = "1", PostId = "post-1" },
            new() { CommentId = "2", PostId = "post-1" }
        };

        _repository.Setup(r => r.GetByPostIdAsync("post-1"))
            .ReturnsAsync(comments);

        var result = await _service.GetByPostIdAsync("post-1");

        Assert.Same(comments, result);
        Assert.All(result, c => Assert.Equal("post-1", c.PostId));
        _repository.Verify(r => r.GetByPostIdAsync("post-1"), Times.Once);
    }

    [Fact]
    public async Task CreateAsync_PassesCommentToRepository()
    {
        var comment = new Comment
        {
            Content = "Test comment",
            PostId = "post-1"
        };

        _repository.Setup(r => r.CreateAsync(comment))
            .Returns(Task.CompletedTask);

        await _service.CreateAsync(comment);

        _repository.Verify(r => r.CreateAsync(comment), Times.Once);
    }

    [Fact]
    public async Task UpdateAsync_PassesCommentToRepository()
    {
        var comment = new Comment
        {
            CommentId = "comment-1",
            Content = "Updated comment"
        };

        _repository.Setup(r => r.UpdateAsync(comment))
            .Returns(Task.CompletedTask);

        await _service.UpdateAsync(comment);

        _repository.Verify(r => r.UpdateAsync(comment), Times.Once);
    }

    [Fact]
    public async Task DeleteAsync_PassesIdToRepository()
    {
        _repository.Setup(r => r.DeleteAsync("comment-1"))
            .Returns(Task.CompletedTask);

        await _service.DeleteAsync("comment-1");

        _repository.Verify(r => r.DeleteAsync("comment-1"), Times.Once);
    }
}