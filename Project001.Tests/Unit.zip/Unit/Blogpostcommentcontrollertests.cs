﻿using Microsoft.AspNetCore.Mvc;
using Project001.Controllers;
using Moq;
using Xunit;

namespace Project001.Tests.Unit.Controllers;

public class BlogsControllerTests
{
    private readonly Mock<IBlogService> _service = new();
    private readonly BlogsController _controller;

    public BlogsControllerTests()
    {
        _controller = new BlogsController(_service.Object);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenIdIsNull()
    {
        var result = await _controller.Details(null);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.GetByIdAsync(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenItemDoesNotExist()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Blog?)null);

        var result = await _controller.Details("missing");

        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task Details_ReturnsViewWithItem_WhenItExists()
    {
        var item = new Blog { BlogId = "blog-1", Title = "Cooking" };
        _service.Setup(s => s.GetByIdAsync("blog-1")).ReturnsAsync(item);

        var result = await _controller.Details("blog-1");

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
    }

    [Fact]
    public async Task Create_Post_ValidModel_CreatesItemAndRedirectsToIndex()
    {
        var item = new Blog { Title = "Cooking" };

        var result = await _controller.Create(item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task Create_Post_InvalidModel_ReturnsViewAndDoesNotCreate()
    {
        var item = new Blog { Title = "Cooking" };
        _controller.ModelState.AddModelError("Title", "Required");

        var result = await _controller.Create(item);

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
        _service.Verify(s => s.CreateAsync(It.IsAny<Blog>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ReturnsNotFound_WhenIdDoesNotMatchModel()
    {
        var item = new Blog { BlogId = "blog-1", Title = "Cooking" };

        var result = await _controller.Edit("blog-2", item);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.UpdateAsync(It.IsAny<Blog>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ValidModel_UpdatesItemAndRedirectsToIndex()
    {
        var item = new Blog { BlogId = "blog-1", Title = "Cooking" };

        var result = await _controller.Edit("blog-1", item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DeletesItemAndRedirects_WhenItExists()
    {
        var item = new Blog { BlogId = "blog-1" };
        _service.Setup(s => s.GetByIdAsync("blog-1")).ReturnsAsync(item);

        var result = await _controller.DeleteConfirmed("blog-1");

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.DeleteAsync("blog-1"), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DoesNotDeleteButRedirects_WhenItemIsMissing()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Blog?)null);

        var result = await _controller.DeleteConfirmed("missing");

        Assert.IsType<RedirectToActionResult>(result);
        _service.Verify(s => s.DeleteAsync(It.IsAny<string>()), Times.Never);
    }
}

public class PostsControllerTests
{
    private readonly Mock<IPostService> _service = new();
    private readonly PostsController _controller;

    public PostsControllerTests()
    {
        _controller = new PostsController(_service.Object);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenIdIsNull()
    {
        var result = await _controller.Details(null);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.GetByIdAsync(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenItemDoesNotExist()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Post?)null);

        var result = await _controller.Details("missing");

        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task Details_ReturnsViewWithItem_WhenItExists()
    {
        var item = new Post { PostId = "post-1", BlogId = "blog-1", Title = "First post" };
        _service.Setup(s => s.GetByIdAsync("post-1")).ReturnsAsync(item);

        var result = await _controller.Details("post-1");

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
    }

    [Fact]
    public async Task Create_Post_ValidModel_CreatesItemAndRedirectsToIndex()
    {
        var item = new Post { BlogId = "blog-1", Title = "First post" };

        var result = await _controller.Create(item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task Create_Post_InvalidModel_ReturnsViewAndDoesNotCreate()
    {
        var item = new Post { BlogId = "blog-1", Title = "First post" };
        _controller.ModelState.AddModelError("Title", "Required");

        var result = await _controller.Create(item);

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
        _service.Verify(s => s.CreateAsync(It.IsAny<Post>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ReturnsNotFound_WhenIdDoesNotMatchModel()
    {
        var item = new Post { PostId = "post-1", BlogId = "blog-1", Title = "First post" };

        var result = await _controller.Edit("post-2", item);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.UpdateAsync(It.IsAny<Post>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ValidModel_UpdatesItemAndRedirectsToIndex()
    {
        var item = new Post { PostId = "post-1", BlogId = "blog-1", Title = "First post" };

        var result = await _controller.Edit("post-1", item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DeletesItemAndRedirects_WhenItExists()
    {
        var item = new Post { PostId = "post-1" };
        _service.Setup(s => s.GetByIdAsync("post-1")).ReturnsAsync(item);

        var result = await _controller.DeleteConfirmed("post-1");

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.DeleteAsync("post-1"), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DoesNotDeleteButRedirects_WhenItemIsMissing()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Post?)null);

        var result = await _controller.DeleteConfirmed("missing");

        Assert.IsType<RedirectToActionResult>(result);
        _service.Verify(s => s.DeleteAsync(It.IsAny<string>()), Times.Never);
    }
}

public class CommentsControllerTests
{
    private readonly Mock<ICommentService> _service = new();
    private readonly CommentsController _controller;

    public CommentsControllerTests()
    {
        _controller = new CommentsController(_service.Object);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenIdIsNull()
    {
        var result = await _controller.Details(null);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.GetByIdAsync(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenItemDoesNotExist()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Comment?)null);

        var result = await _controller.Details("missing");

        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task Details_ReturnsViewWithItem_WhenItExists()
    {
        var item = new Comment { CommentId = "comment-1", PostId = "post-1", Content = "Nice" };
        _service.Setup(s => s.GetByIdAsync("comment-1")).ReturnsAsync(item);

        var result = await _controller.Details("comment-1");

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
    }

    [Fact]
    public async Task Create_Post_ValidModel_CreatesItemAndRedirectsToIndex()
    {
        var item = new Comment { PostId = "post-1", Content = "Nice" };

        var result = await _controller.Create(item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task Create_Post_InvalidModel_ReturnsViewAndDoesNotCreate()
    {
        var item = new Comment { PostId = "post-1", Content = "Nice" };
        _controller.ModelState.AddModelError("Title", "Required");

        var result = await _controller.Create(item);

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
        _service.Verify(s => s.CreateAsync(It.IsAny<Comment>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ReturnsNotFound_WhenIdDoesNotMatchModel()
    {
        var item = new Comment { CommentId = "comment-1", PostId = "post-1", Content = "Nice" };

        var result = await _controller.Edit("comment-2", item);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.UpdateAsync(It.IsAny<Comment>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ValidModel_UpdatesItemAndRedirectsToIndex()
    {
        var item = new Comment { CommentId = "comment-1", PostId = "post-1", Content = "Nice" };

        var result = await _controller.Edit("comment-1", item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DeletesItemAndRedirects_WhenItExists()
    {
        var item = new Comment { CommentId = "comment-1" };
        _service.Setup(s => s.GetByIdAsync("comment-1")).ReturnsAsync(item);

        var result = await _controller.DeleteConfirmed("comment-1");

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.DeleteAsync("comment-1"), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DoesNotDeleteButRedirects_WhenItemIsMissing()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Comment?)null);

        var result = await _controller.DeleteConfirmed("missing");

        Assert.IsType<RedirectToActionResult>(result);
        _service.Verify(s => s.DeleteAsync(It.IsAny<string>()), Times.Never);
    }
}