﻿using Microsoft.AspNetCore.Mvc;
using Project001.Controllers;
using Moq;
using Xunit;

namespace Project001.Tests.Unit.Controllers;

public class RecipesControllerTests
{
    private readonly Mock<IRecipeService> _service = new();
    private readonly RecipesController _controller;

    public RecipesControllerTests()
    {
        _controller = new RecipesController(_service.Object);
    }

    [Fact]
    public async Task 
        
        
        _ReturnsNotFound_WhenIdIsNull()
    {
        var result = await _controller.Details(null);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.GetByIdAsync(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenItemDoesNotExist()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Recipe?)null);

        var result = await _controller.Details("missing");

        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task Details_ReturnsViewWithItem_WhenItExists()
    {
        var item = new Recipe { RecipeId = "recipe-1", Title = "Pasta" };
        _service.Setup(s => s.GetByIdAsync("recipe-1")).ReturnsAsync(item);

        var result = await _controller.Details("recipe-1");

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
    }

    [Fact]
    public async Task Create_Post_ValidModel_CreatesItemAndRedirectsToIndex()
    {
        var item = new Recipe { Title = "Pasta" };

        var result = await _controller.Create(item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task Create_Post_InvalidModel_ReturnsViewAndDoesNotCreate()
    {
        var item = new Recipe { Title = "Pasta" };
        _controller.ModelState.AddModelError("Title", "Required");

        var result = await _controller.Create(item);

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
        _service.Verify(s => s.CreateAsync(It.IsAny<Recipe>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ReturnsNotFound_WhenIdDoesNotMatchModel()
    {
        var item = new Recipe { RecipeId = "recipe-1", Title = "Pasta" };

        var result = await _controller.Edit("recipe-2", item);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.UpdateAsync(It.IsAny<Recipe>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ValidModel_UpdatesItemAndRedirectsToIndex()
    {
        var item = new Recipe { RecipeId = "recipe-1", Title = "Pasta" };

        var result = await _controller.Edit("recipe-1", item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DeletesItemAndRedirects_WhenItExists()
    {
        var item = new Recipe { RecipeId = "recipe-1" };
        _service.Setup(s => s.GetByIdAsync("recipe-1")).ReturnsAsync(item);

        var result = await _controller.DeleteConfirmed("recipe-1");

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.DeleteAsync("recipe-1"), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DoesNotDeleteButRedirects_WhenItemIsMissing()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Recipe?)null);

        var result = await _controller.DeleteConfirmed("missing");

        Assert.IsType<RedirectToActionResult>(result);
        _service.Verify(s => s.DeleteAsync(It.IsAny<string>()), Times.Never);
    }
}

public class RatingsControllerTests
{
    private readonly Mock<IRatingService> _service = new();
    private readonly RatingsController _controller;

    public RatingsControllerTests()
    {
        _controller = new RatingsController(_service.Object);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenIdIsNull()
    {
        var result = await _controller.Details(null);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.GetByIdAsync(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task Details_ReturnsNotFound_WhenItemDoesNotExist()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Rating?)null);

        var result = await _controller.Details("missing");

        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task Details_ReturnsViewWithItem_WhenItExists()
    {
        var item = new Rating { RatingId = "rating-1", RecipeId = "recipe-1", Value = 5 };
        _service.Setup(s => s.GetByIdAsync("rating-1")).ReturnsAsync(item);

        var result = await _controller.Details("rating-1");

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
    }

    [Fact]
    public async Task Create_Post_ValidModel_CreatesItemAndRedirectsToIndex()
    {
        var item = new Rating { RecipeId = "recipe-1", Value = 5 };

        var result = await _controller.Create(item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.CreateAsync(item), Times.Once);
    }

    [Fact]
    public async Task Create_Post_InvalidModel_ReturnsViewAndDoesNotCreate()
    {
        var item = new Rating { RecipeId = "recipe-1", Value = 5 };
        _controller.ModelState.AddModelError("Title", "Required");

        var result = await _controller.Create(item);

        var view = Assert.IsType<ViewResult>(result);
        Assert.Same(item, view.Model);
        _service.Verify(s => s.CreateAsync(It.IsAny<Rating>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ReturnsNotFound_WhenIdDoesNotMatchModel()
    {
        var item = new Rating { RatingId = "rating-1", RecipeId = "recipe-1", Value = 5 };

        var result = await _controller.Edit("rating-2", item);

        Assert.IsType<NotFoundResult>(result);
        _service.Verify(s => s.UpdateAsync(It.IsAny<Rating>()), Times.Never);
    }

    [Fact]
    public async Task Edit_Post_ValidModel_UpdatesItemAndRedirectsToIndex()
    {
        var item = new Rating { RatingId = "rating-1", RecipeId = "recipe-1", Value = 5 };

        var result = await _controller.Edit("rating-1", item);

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.UpdateAsync(item), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DeletesItemAndRedirects_WhenItExists()
    {
        var item = new Rating { RatingId = "rating-1" };
        _service.Setup(s => s.GetByIdAsync("rating-1")).ReturnsAsync(item);

        var result = await _controller.DeleteConfirmed("rating-1");

        var redirect = Assert.IsType<RedirectToActionResult>(result);
        Assert.Equal("Index", redirect.ActionName);
        _service.Verify(s => s.DeleteAsync("rating-1"), Times.Once);
    }

    [Fact]
    public async Task DeleteConfirmed_DoesNotDeleteButRedirects_WhenItemIsMissing()
    {
        _service.Setup(s => s.GetByIdAsync("missing")).ReturnsAsync((Rating?)null);

        var result = await _controller.DeleteConfirmed("missing");

        Assert.IsType<RedirectToActionResult>(result);
        _service.Verify(s => s.DeleteAsync(It.IsAny<string>()), Times.Never);
    }
}